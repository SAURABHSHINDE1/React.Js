import img1 from './assets/clgimg.jpg';
import img2 from './assets/img.jpg';
import img3 from './assets/smbt.jpg';

const images = [{src:img1, caption:"We provide a safe, inclusive, and inspiring environment where students thrive academically "},
{src:img2, caption:"We are better"},
{src:img3, caption:"We are best"},
];

export default images;