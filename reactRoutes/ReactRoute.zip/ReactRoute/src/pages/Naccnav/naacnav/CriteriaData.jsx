import React from "react";

const criteriaData = [
  { title: "Extended Profile", count: 8, link: "" },
  { title: "Criteria- I Curricular Aspects", count: 11, link: "" },
  { title: "Criteria-II Teaching- Learning and Evaluation", count: 8, link: "" },
  { title: "Criterion 3 – Research, Innovations and Extension", count: 7, link: "" },
  { title: "Criterion 4 - Infrastructure and Learning Resources", count: 8, link: "" },
  { title: "Criterion 5 - Student Support and Progression", count: 9, link: "" },
  { title: "Criterion 6- Governance, Leadership and Management", count: 5, link: "" },
  { title: "Criterion 7- Institutional Values and Best Practices", count: 10, link: "" },
  { title: "AQAR 2020-21", count: 9, link: "" },
  { title: "AQAR 2020-21", count: 0, link: "" },
  { title: "AQAR Documents", count: 9, link: "" },
  { title: "AQAR 2022-23", count: 25, link: "" },
  { title: "AQAR 2023-24", count: 28, link: "" },
];

export default criteriaData;