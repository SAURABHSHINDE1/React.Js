import React from 'react'
import './NaacBar.css';

function NaacBar () {
    return (
        <div className='container-Front'>
            <h2>NAAC/IQAC</h2>
        </div>
    )
}

export default NaacBar