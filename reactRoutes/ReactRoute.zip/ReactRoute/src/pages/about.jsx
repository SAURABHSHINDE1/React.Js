export const About =()=>{
    
    return <h1>About Page</h1>
}