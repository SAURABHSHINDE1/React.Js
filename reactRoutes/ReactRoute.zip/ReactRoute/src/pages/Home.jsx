import Carsole from "./carsol"
import ChairmanCards from "./chairman"

export const Home =()=>{
    
    return <>

     <Carsole />

     <ChairmanCards />
    
     </> 
}